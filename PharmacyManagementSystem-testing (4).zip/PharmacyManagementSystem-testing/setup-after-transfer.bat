@echo off
echo Setting up Pharmacy Management System...
echo.

echo Step 1: Restoring .NET dependencies...
cd PharmacyManagement
dotnet restore
cd ..

echo.
echo Step 2: Installing Angular dependencies (this may take a few minutes)...
cd angular-frontend
call npm install
cd ..

echo.
echo Setup complete!
echo.
echo To run the project:
echo 1. Backend: Run start-backend.bat
echo 2. Frontend: Run start-frontend.bat
echo.
pause