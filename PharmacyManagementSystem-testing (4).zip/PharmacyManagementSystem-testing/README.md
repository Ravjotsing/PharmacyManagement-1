# Pharmacy Management System - Setup & Run Guide

## Prerequisites
- .NET 8 SDK
- Node.js (v16 or higher)
- SQL Server
- Visual Studio Code or Visual Studio

## Backend Setup (.NET Core API)

### 1. Configure Database Connection
Edit `PharmacyManagement/appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=YOUR_SERVER;Database=PharmacyDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

### 2. Run Database Migrations
```bash
cd PharmacyManagement
dotnet ef database update
```

### 3. Start Backend Server
```bash
dotnet run
```
Backend will run on: `https://localhost:7000` or `http://localhost:5000`

## Frontend Setup (Angular)

### 1. Install Dependencies
```bash
cd angular-frontend
npm install
```

### 2. Update API URL (if needed)
Edit service files in `src/app/services/` and update:
```typescript
private apiUrl = 'https://localhost:7000/api/...';
```

### 3. Start Frontend Server
```bash
npm start
```
Frontend will run on: `http://localhost:4200`

## Quick Start (Both Servers)

### Option 1: Manual Start
**Terminal 1 (Backend):**
```bash
cd PharmacyManagement
dotnet run
```

**Terminal 2 (Frontend):**
```bash
cd angular-frontend
npm start
```

### Option 2: Using Batch Files (Windows)

**Start Backend:**
Double-click `start-backend.bat` or run:
```bash
start-backend.bat
```

**Start Frontend:**
Create and run `start-frontend.bat`:
```bash
cd angular-frontend
npm start
pause
```

## Access the Application

1. Open browser: `http://localhost:4200`
2. Login page will appear
3. Register a new user or use existing credentials
4. Navigate to different sections using the menu

## Default Test Credentials (if seeded)
- **Admin:** admin@pharmacy.com / Admin@123
- **User:** user@pharmacy.com / User@123

## API Documentation
Once backend is running, access Swagger UI:
`https://localhost:7000/swagger`

## Troubleshooting

### Backend Issues:
- **Database connection failed:** Check SQL Server is running and connection string is correct
- **Port already in use:** Change port in `Properties/launchSettings.json`
- **Migration errors:** Run `dotnet ef database drop` then `dotnet ef database update`

### Frontend Issues:
- **Blank screen:** Check browser console (F12) for errors
- **API connection failed:** Verify backend is running on correct port
- **CORS errors:** Ensure backend CORS is configured for `http://localhost:4200`

### Common Commands:
```bash
# Backend
dotnet build                    # Build project
dotnet clean                    # Clean build files
dotnet ef migrations add Name   # Add new migration
dotnet ef database update       # Apply migrations

# Frontend
npm install                     # Install dependencies
npm start                       # Start dev server
npm run build                   # Build for production
```

## Project Structure

```
PharmacyManagementSystem-testing/
├── PharmacyManagement/          # Backend API
│   ├── Controllers/             # API endpoints
│   ├── Services/                # Business logic
│   ├── Repository/              # Data access
│   ├── Models/                  # Database models
│   ├── DTO/                     # Data transfer objects
│   └── Program.cs               # Entry point
│
└── angular-frontend/            # Frontend
    └── src/
        └── app/
            ├── components/      # UI components
            ├── services/        # API services
            └── models/          # TypeScript models
```

## Testing the Application

1. **Register User:** Go to login page → Register
2. **Login:** Use credentials to login
3. **View Drugs:** Navigate to drugs section
4. **Add Drug (Admin only):** Fill form and submit
5. **Manage Inventory:** Access inventory section
6. **View Sales/Orders:** Check sales and orders sections

## Notes
- Backend must be running before starting frontend
- Default ports: Backend (7000), Frontend (4200)
- Admin features require admin role login
- Check Swagger for complete API documentation