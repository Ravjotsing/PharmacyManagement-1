@echo off
echo Aggressive cleanup for transfer...
echo.

echo Deleting node_modules...
if exist "angular-frontend\node_modules" rmdir /s /q "angular-frontend\node_modules"

echo Deleting ALL bin folders...
for /d /r . %%d in (bin) do @if exist "%%d" rmdir /s /q "%%d"

echo Deleting ALL obj folders...
for /d /r . %%d in (obj) do @if exist "%%d" rmdir /s /q "%%d"

echo Deleting dist folder...
if exist "angular-frontend\dist" rmdir /s /q "angular-frontend\dist"

echo Deleting .angular cache...
if exist "angular-frontend\.angular" rmdir /s /q "angular-frontend\.angular"

echo Deleting package-lock.json (will regenerate)...
if exist "angular-frontend\package-lock.json" del /q "angular-frontend\package-lock.json"

echo.
echo Cleanup complete! Check folder size now.
echo.
pause