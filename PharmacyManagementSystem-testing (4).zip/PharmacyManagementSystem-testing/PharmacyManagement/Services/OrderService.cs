using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using PharmacyManagement.Models;
using PharmacyManagement.Data;

namespace PharmacyManagement.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ApplicationDbContext _context;
        private readonly IDrugsService _drugsService;
        private readonly IMapper _mapper;
        private readonly ILogger<OrderService> _logger;

        public OrderService(IOrderRepository orderRepository, ApplicationDbContext context,IDrugsService drugsService, IMapper mapper, ILogger<OrderService> logger)
        {
            _orderRepository = orderRepository;
            _context = context;
            _drugsService = drugsService;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<IEnumerable<OrderDto>> GetAllOrdersAsync()
        {
            var orders = await _orderRepository.GetAllOrdersAsync();
            return _mapper.Map<IEnumerable<OrderDto>>(orders);
        }

        public async Task<OrderDto?> GetOrderByIdAsync(int id)
        {
            var order = await _orderRepository.GetOrderByIdAsync(id);
            return _mapper.Map<OrderDto?>(order);
        }

        public async Task<IEnumerable<OrderDto>> GetOrdersByDoctorIdAsync(int doctorId)
        {
            var orders = await _orderRepository.GetOrdersByDoctorIdAsync(doctorId);
            return _mapper.Map<IEnumerable<OrderDto>>(orders);
        }

        public async Task<OrderDto> CreateOrderAsync(CreateOrderDto dto)
        {
            _logger.LogInformation("Creating order for Doctor {DoctorId} and Drug {DrugId}", dto.DoctorId, dto.DrugId);

            var drug = await _context.Drugs.FindAsync(dto.DrugId)
                       ?? throw new KeyNotFoundException("Drug not found.");

            if (drug.Stock < dto.Quantity)
                throw new InvalidOperationException("Insufficient stock available.");

            await DeductInventoryAsync(dto.DrugId, dto.Quantity);
            await _drugsService.UpdateDrugStockAsync(dto.DrugId);
            
            //drug.Stock -= dto.Quantity;

            await _context.SaveChangesAsync();

            var order = _mapper.Map<Order>(dto);
            var createdOrder = await _orderRepository.CreateOrderAsync(order);
            return _mapper.Map<OrderDto>(createdOrder);
        }

        public async Task<OrderDto?> UpdateOrderAsync(int id, UpdateOrderDto dto)
        {
            var existing = await _orderRepository.GetOrderByIdAsync(id)
                           ?? throw new KeyNotFoundException($"Order with ID {id} not found.");

            _mapper.Map(dto, existing);
            var updated = await _orderRepository.UpdateOrderAsync(existing);
            return _mapper.Map<OrderDto?>(updated);
        }

        public async Task<bool> DeleteOrderAsync(int id)
        {
            var result = await _orderRepository.DeleteOrderAsync(id);
            if (!result)
                throw new KeyNotFoundException($"Order with ID {id} not found.");
            return result;
        }
        private async Task DeductInventoryAsync(int drugId, int quantityNeeded)
        {
            var inventories = await _context.Inventory
                .Where(i => i.DrugId == drugId && i.Quantity > 0)
                .OrderBy(i => i.LastRestockDate)
                .ToListAsync();

            foreach (var inventory in inventories)
            {
                if (quantityNeeded <= 0) break;

                if (inventory.Quantity >= quantityNeeded)
                {
                    inventory.Quantity -= quantityNeeded;
                    quantityNeeded = 0;
                }
                else
                {
                    quantityNeeded -= inventory.Quantity;
                    inventory.Quantity = 0;
                }
                _context.Inventory.Update(inventory);
            }

            if (quantityNeeded > 0)
                throw new InvalidOperationException("Not enough inventory batches to fulfill this order.");

            await _context.SaveChangesAsync();
        }
    }
}