using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using PharmacyManagement.Models;
using AutoMapper;
using System.Threading.Tasks;

namespace PharmacyManagement.Services
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository _authRepository;
        private readonly IMapper _mapper;
                                                                                        
        public AuthService(IAuthRepository authRepository, IMapper mapper)
        {
            _authRepository = authRepository;
            _mapper = mapper;
        
        }

        public async Task<string> RegisterAsync(RegisterDto model)
        {
            var user = _mapper.Map<User>(model);
            user.UserName = model.Name;
            user.Role = "Doctor";
            var (isSuccess, message) = await _authRepository.RegisterAsync(user, model.Password);
            //var (isSuccess, message) = await _authRepository.RegisterAsync(user, model.Password);
            return isSuccess ? "User registered successfully." : $"Registration failed: {message}";
        }

        public Task<string?> LoginAsync(LoginDto model)
        {
            return _authRepository.LoginAsync(model.Email?.Trim(), model.Password);
        }
        
        public async Task<string?> LoginAdminAsync(LoginDto model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.Email))
                return null;

            var email = model.Email.Trim();
            var user = await _authRepository.GetUserByEmailAsync(email);
            if (user?.Role != "Admin")
                return null;

            return await _authRepository.LoginAsync(email, model.Password);
        }

    }
}