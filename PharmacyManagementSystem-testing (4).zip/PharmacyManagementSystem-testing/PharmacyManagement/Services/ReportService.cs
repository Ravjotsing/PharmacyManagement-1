using Microsoft.EntityFrameworkCore;
using PharmacyManagement.Data;
using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using OfficeOpenXml;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace PharmacyManagement.Services
{
    public class ReportService : IReportService
    {
        private readonly ApplicationDbContext _context;

        public ReportService(ApplicationDbContext context)
        {
            _context = context;
            // Set EPPlus license context
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public async Task<byte[]> GenerateSalesReportAsync(SalesReportRequestDto request)
        {
            var salesData = await GetSalesDataAsync(request);

            return request.Format switch
            {
                ReportFormat.CSV => await GenerateCsvReportAsync(salesData),
                ReportFormat.Excel => await GenerateExcelReportAsync(salesData),
                ReportFormat.PDF => await GeneratePdfReportAsync(salesData),
                _ => throw new ArgumentException("Invalid report format")
            };
        }

        public async Task<string> GetReportContentTypeAsync(ReportFormat format)
        {
            return await Task.FromResult(format switch
            {
                ReportFormat.CSV => "text/csv",
                ReportFormat.Excel => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ReportFormat.PDF => "application/pdf",
                _ => "application/octet-stream"
            });
        }

        public async Task<string> GetReportFileNameAsync(ReportFormat format)
        {
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            return await Task.FromResult(format switch
            {
                ReportFormat.CSV => $"SalesReport_{timestamp}.csv",
                ReportFormat.Excel => $"SalesReport_{timestamp}.xlsx",
                ReportFormat.PDF => $"SalesReport_{timestamp}.pdf",
                _ => $"SalesReport_{timestamp}.txt"
            });
        }

        private async Task<List<SalesReportDto>> GetSalesDataAsync(SalesReportRequestDto request)
        {
            var query = _context.Sales
                .Include(s => s.Drug)
                .AsQueryable();

            if (request.StartDate.HasValue)
                query = query.Where(s => s.Date >= request.StartDate.Value);

            if (request.EndDate.HasValue)
                query = query.Where(s => s.Date <= request.EndDate.Value);

            if (request.DrugId.HasValue)
                query = query.Where(s => s.DrugId == request.DrugId.Value);

            if (!string.IsNullOrEmpty(request.PaymentMethod))
                query = query.Where(s => s.PaymentMethod.Contains(request.PaymentMethod));

            var sales = await query
                .OrderByDescending(s => s.Date)
                .Select(s => new SalesReportDto
                {
                    SalesId = s.SalesId,
                    Date = s.Date,
                    TotalSales = s.TotalSales,
                    DrugId = s.DrugId,
                    DrugName = s.Drug.Name,
                    PaymentMethod = s.PaymentMethod,
                    CustomerInfo = "N/A" // Add customer info if available in your model
                })
                .ToListAsync();

            return sales;
        }

        private async Task<byte[]> GenerateCsvReportAsync(List<SalesReportDto> salesData)
        {
            using var memoryStream = new MemoryStream();
            using var writer = new StreamWriter(memoryStream);
            using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);

            await csv.WriteRecordsAsync(salesData);
            await writer.FlushAsync();

            return memoryStream.ToArray();
        }

        private async Task<byte[]> GenerateExcelReportAsync(List<SalesReportDto> salesData)
        {
            using var package = new ExcelPackage();
            var worksheet = package.Workbook.Worksheets.Add("Sales Report");

            // Headers
            worksheet.Cells[1, 1].Value = "Sales ID";
            worksheet.Cells[1, 2].Value = "Date";
            worksheet.Cells[1, 3].Value = "Drug Name";
            worksheet.Cells[1, 4].Value = "Total Sales";
            worksheet.Cells[1, 5].Value = "Payment Method";
            worksheet.Cells[1, 6].Value = "Customer Info";

            // Style headers
            using (var range = worksheet.Cells[1, 1, 1, 6])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            }

            // Data
            for (int i = 0; i < salesData.Count; i++)
            {
                var sale = salesData[i];
                worksheet.Cells[i + 2, 1].Value = sale.SalesId;
                worksheet.Cells[i + 2, 2].Value = sale.Date.ToString("yyyy-MM-dd");
                worksheet.Cells[i + 2, 3].Value = sale.DrugName;
                worksheet.Cells[i + 2, 4].Value = sale.TotalSales;
                worksheet.Cells[i + 2, 5].Value = sale.PaymentMethod;
                worksheet.Cells[i + 2, 6].Value = sale.CustomerInfo;
            }

            // Auto-fit columns
            worksheet.Cells.AutoFitColumns();

            // Add summary
            var lastRow = salesData.Count + 3;
            worksheet.Cells[lastRow, 3].Value = "Total Sales:";
            worksheet.Cells[lastRow, 4].Value = salesData.Sum(s => s.TotalSales);
            worksheet.Cells[lastRow, 3, lastRow, 4].Style.Font.Bold = true;

            return await Task.FromResult(package.GetAsByteArray());
        }

        private async Task<byte[]> GeneratePdfReportAsync(List<SalesReportDto> salesData)
        {
            using var memoryStream = new MemoryStream();
            var document = new Document(PageSize.A4.Rotate(), 10, 10, 10, 10);
            var writer = PdfWriter.GetInstance(document, memoryStream);

            document.Open();

            // Title
            var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
            var title = new Paragraph("Sales Report", titleFont)
            {
                Alignment = Element.ALIGN_CENTER,
                SpacingAfter = 20
            };
            document.Add(title);

            // Report generation date
            var dateFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);
            var dateInfo = new Paragraph($"Generated on: {DateTime.Now:yyyy-MM-dd HH:mm:ss}", dateFont)
            {
                Alignment = Element.ALIGN_RIGHT,
                SpacingAfter = 20
            };
            document.Add(dateInfo);

            // Table
            var table = new PdfPTable(6)
            {
                WidthPercentage = 100
            };
            table.SetWidths(new float[] { 1, 2, 3, 2, 2, 2 });

            // Headers
            var headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10);
            table.AddCell(new PdfPCell(new Phrase("Sales ID", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });
            table.AddCell(new PdfPCell(new Phrase("Date", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });
            table.AddCell(new PdfPCell(new Phrase("Drug Name", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });
            table.AddCell(new PdfPCell(new Phrase("Total Sales", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });
            table.AddCell(new PdfPCell(new Phrase("Payment Method", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });
            table.AddCell(new PdfPCell(new Phrase("Customer Info", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });

            // Data
            var cellFont = FontFactory.GetFont(FontFactory.HELVETICA, 9);
            foreach (var sale in salesData)
            {
                table.AddCell(new PdfPCell(new Phrase(sale.SalesId.ToString(), cellFont)));
                table.AddCell(new PdfPCell(new Phrase(sale.Date.ToString("yyyy-MM-dd"), cellFont)));
                table.AddCell(new PdfPCell(new Phrase(sale.DrugName, cellFont)));
                table.AddCell(new PdfPCell(new Phrase(sale.TotalSales.ToString("C"), cellFont)));
                table.AddCell(new PdfPCell(new Phrase(sale.PaymentMethod, cellFont)));
                table.AddCell(new PdfPCell(new Phrase(sale.CustomerInfo, cellFont)));
            }

            document.Add(table);

            // Summary
            var totalSales = salesData.Sum(s => s.TotalSales);
            var summaryParagraph = new Paragraph($"\nTotal Sales: {totalSales:C}", headerFont)
            {
                Alignment = Element.ALIGN_RIGHT
            };
            document.Add(summaryParagraph);

            document.Close();

            return await Task.FromResult(memoryStream.ToArray());
        }
    }
}