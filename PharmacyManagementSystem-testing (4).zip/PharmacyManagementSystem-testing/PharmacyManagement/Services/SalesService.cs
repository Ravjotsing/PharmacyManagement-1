using AutoMapper;
using Microsoft.Extensions.Logging;
using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using PharmacyManagement.Models;
using Microsoft.EntityFrameworkCore;
using PharmacyManagement.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace PharmacyManagement.Services
{
    public class SalesService : ISalesService
    {
        private readonly ISalesRepository _salesRepository;
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly ILogger<SalesService> _logger;

        public SalesService(ISalesRepository repo, ApplicationDbContext context, IMapper mapper, ILogger<SalesService> logger)
        {
            _salesRepository = repo;
            _context = context;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<IEnumerable<SaleDto>> GetAllSalesAsync()
        {
            var sales = await _salesRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<SaleDto>>(sales);
        }

        public async Task<SaleDto> GetSaleByIdAsync(int id)
        {
            var sale = await _salesRepository.GetByIdAsync(id);
            if (sale == null)
                throw new KeyNotFoundException($"Sale with ID {id} not found.");

            return _mapper.Map<SaleDto>(sale);
        }

        public async Task<SaleDto> CreateSaleAsync(CreateSaleDto dto)
        {
            bool drugExists = await _context.Drugs.AnyAsync(d => d.DrugId == dto.DrugId);
            if (!drugExists)
                throw new KeyNotFoundException($"Drug with ID {dto.DrugId} not found.");

            var sale = _mapper.Map<Sales>(dto);
            var created = await _salesRepository.CreateAsync(sale);
            return _mapper.Map<SaleDto>(created);
        }

        public async Task<SaleDto> UpdateSaleAsync(int id, UpdateSaleDto dto)
        {
            var existing = await _salesRepository.GetByIdAsync(id);
            if (existing == null)
                throw new KeyNotFoundException($"Sale with ID {id} not found.");

            bool drugExists = await _context.Drugs.AnyAsync(d => d.DrugId == dto.DrugId);
            if (!drugExists)
                throw new KeyNotFoundException($"Drug with ID {dto.DrugId} not found.");

            _mapper.Map(dto, existing);
            var updated = await _salesRepository.UpdateAsync(id, existing)!;
            return _mapper.Map<SaleDto>(updated);
        }

        public async Task DeleteSaleAsync(int id)
        {
            var result = await _salesRepository.DeleteAsync(id);
            if (!result)
                throw new KeyNotFoundException($"Sale with ID {id} not found.");
        }
    }
}