using AutoMapper;
using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using PharmacyManagement.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PharmacyManagement.Services
{
    public class SupplierService : ISupplierService
    {
        private readonly ISupplierRepository _repository;
        private readonly IMapper _mapper;

        public SupplierService(ISupplierRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SupplierDto>> GetAllSuppliersAsync()
        {
            var suppliers = await _repository.GetAllAsync();
            return _mapper.Map<IEnumerable<SupplierDto>>(suppliers);
        }

        public async Task<SupplierDto> AddSupplierAsync(CreateSupplierDto supplierDto)
        {
            if (await _repository.EmailExistsAsync(supplierDto.Email))
                throw new InvalidOperationException($"Supplier with email '{supplierDto.Email}' already exists.");

            var supplier = _mapper.Map<Supplier>(supplierDto);
            var addedSupplier = await _repository.AddAsync(supplier);

            return _mapper.Map<SupplierDto>(addedSupplier);
        }
    }
}