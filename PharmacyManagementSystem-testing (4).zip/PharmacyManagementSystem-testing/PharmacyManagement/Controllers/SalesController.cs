using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PharmacyManagement.DTO;
using PharmacyManagement.Interface;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Authorization;

namespace PharmacyManagement.Controllers
{
    [ApiController]
    [Route("api/sales")]
    public class SalesController : ControllerBase
    {
        private readonly ISalesService _salesService;
        private readonly IReportService _reportService;
        private readonly ILogger<SalesController> _logger;

        public SalesController(ISalesService salesService, IReportService reportService, ILogger<SalesController> logger)
        {
            _salesService = salesService;
            _reportService = reportService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var sales = await _salesService.GetAllSalesAsync();
            return Ok(sales);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var sale = await _salesService.GetSaleByIdAsync(id);
            return Ok(sale);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateSaleDto dto)
        {
            var sale = await _salesService.CreateSaleAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = sale.SalesId }, sale);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateSaleDto dto)
        {
            var sale = await _salesService.UpdateSaleAsync(id, dto);
            return Ok(sale);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _salesService.DeleteSaleAsync(id);
            return NoContent();
        }

        [HttpPost("report/download")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DownloadSalesReport([FromBody] SalesReportRequestDto request)
        {
            try
            {
                var reportData = await _reportService.GenerateSalesReportAsync(request);
                var contentType = await _reportService.GetReportContentTypeAsync(request.Format);
                var fileName = await _reportService.GetReportFileNameAsync(request.Format);

                return File(reportData, contentType, fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating sales report");
                return BadRequest("Error generating report: " + ex.Message);
            }
        }

        [HttpGet("report/download")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DownloadSalesReportGet(
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate,
            [FromQuery] int? drugId,
            [FromQuery] string? paymentMethod,
            [FromQuery] ReportFormat format = ReportFormat.CSV)
        {
            try
            {
                var request = new SalesReportRequestDto
                {
                    StartDate = startDate,
                    EndDate = endDate,
                    DrugId = drugId,
                    PaymentMethod = paymentMethod,
                    Format = format
                };

                var reportData = await _reportService.GenerateSalesReportAsync(request);
                var contentType = await _reportService.GetReportContentTypeAsync(request.Format);
                var fileName = await _reportService.GetReportFileNameAsync(request.Format);

                return File(reportData, contentType, fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating sales report");
                return BadRequest("Error generating report: " + ex.Message);
            }
        }
    }
}