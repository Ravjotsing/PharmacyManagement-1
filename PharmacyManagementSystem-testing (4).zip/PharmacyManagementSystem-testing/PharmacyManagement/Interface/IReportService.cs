using PharmacyManagement.DTO;
using System.Threading.Tasks;

namespace PharmacyManagement.Interface
{
    public interface IReportService
    {
        Task<byte[]> GenerateSalesReportAsync(SalesReportRequestDto request);
        Task<string> GetReportContentTypeAsync(ReportFormat format);
        Task<string> GetReportFileNameAsync(ReportFormat format);
    }
}