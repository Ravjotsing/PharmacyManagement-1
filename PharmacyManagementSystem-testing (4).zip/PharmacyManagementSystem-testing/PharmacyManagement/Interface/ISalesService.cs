using PharmacyManagement.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PharmacyManagement.Interface
{
    public interface ISalesService
    {
        Task<IEnumerable<SaleDto>> GetAllSalesAsync();
        Task<SaleDto> GetSaleByIdAsync(int id);
        Task<SaleDto> CreateSaleAsync(CreateSaleDto dto);
        Task<SaleDto> UpdateSaleAsync(int id, UpdateSaleDto dto);
        Task DeleteSaleAsync(int id);
    }
}