using PharmacyManagement.DTO;
using PharmacyManagement.Models;
namespace PharmacyManagement.Interface
{
    public interface IDrugsService
    {
        Task<IEnumerable<DrugDto>> GetAllDrugsAsync();
        Task<DrugDto?> GetDrugByIdAsync(int id);
        Task<DrugDto> AddDrugAsync(CreateDrugDto drugDto);
        Task<DrugDto?> UpdateDrugAsync(int id, UpdateDrugDto drugdto);
        Task<bool> DeleteDrugAsync(int id);
        Task UpdateDrugStockAsync(int drugId);
         Task<Drug?> GetByNameAsync(string name);
    }
}