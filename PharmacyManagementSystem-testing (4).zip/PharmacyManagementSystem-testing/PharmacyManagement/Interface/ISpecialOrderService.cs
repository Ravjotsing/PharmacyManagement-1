
using PharmacyManagement.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PharmacyManagement.Interface
{
    public interface ISpecialOrderService
    {
        Task<SpecialOrderDto?> GetByIdAsync(int id);
        Task<IEnumerable<SpecialOrderDto>> GetAllAsync();
        Task<IEnumerable<SpecialOrderDto>> GetByDoctorIdAsync(int doctorId);
        Task<SpecialOrderDto> CreateAsync(CreateSpecialOrderDto dto);
        Task<bool> UpdateStatusAsync(int id, UpdateSpecialOrderStatusDto dto);
    }
}