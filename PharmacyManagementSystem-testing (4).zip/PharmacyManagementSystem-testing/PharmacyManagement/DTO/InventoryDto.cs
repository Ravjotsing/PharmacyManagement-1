using System;
using System.ComponentModel.DataAnnotations;

namespace PharmacyManagement.DTO
{
    
    public class AddInventoryDto
    {
        [Required]
        public string DrugName { get; set; }
        [Required]
        public int SupplierId { get; set; }
        [Range(1, int.MaxValue)] // Assuming you add at least 1
        public int Quantity { get; set; }

       
        
        
    }

    
     public class ReadInventoryDto
    {
         public int Id { get; set; }
         public int DrugId { get; set; }
         public string DrugName { get; set; }
         public int SupplierId { get; set; }
         public string SupplierName { get; set; }
         public int Quantity { get; set; }
        
         public DateTime? LastRestockDate { get; set; }
        
         public string? DrugStorageInstructions { get; set; }
    }

   
    public class UpdateInventoryQuantityDto
    {
        [Range(0, int.MaxValue)] 
        public int NewQuantity { get; set; }
       
    }
}
