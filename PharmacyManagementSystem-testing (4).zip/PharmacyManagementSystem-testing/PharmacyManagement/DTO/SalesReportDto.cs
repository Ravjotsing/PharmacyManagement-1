using System;
using System.ComponentModel.DataAnnotations;

namespace PharmacyManagement.DTO
{
    public class SalesReportRequestDto
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? DrugId { get; set; }
        public string? PaymentMethod { get; set; }
        
        [Required]
        public ReportFormat Format { get; set; } = ReportFormat.CSV;
    }

    public class SalesReportDto
    {
        public int SalesId { get; set; }
        public DateTime Date { get; set; }
        public decimal TotalSales { get; set; }
        public int DrugId { get; set; }
        public string DrugName { get; set; }
        public string PaymentMethod { get; set; }
        public string CustomerInfo { get; set; }
    }

    public enum ReportFormat
    {
        CSV = 1,
        Excel = 2,
        PDF = 3
    }
}