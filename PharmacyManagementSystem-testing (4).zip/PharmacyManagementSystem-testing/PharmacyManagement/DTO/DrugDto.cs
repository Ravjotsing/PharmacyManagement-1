using System.ComponentModel.DataAnnotations;

namespace PharmacyManagement.DTO
{
    
    public class DrugDto
    {
        public int DrugId { get; set; }
        public string Name { get; set; }
        public string Manufacturer { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public string? StorageInstructions { get; set; }
        public bool IsPrescriptionRequired { get; set; }
       
    }

    // DTO for creating a new Drug
    public class CreateDrugDto
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string Manufacturer { get; set; }
        [Range(0.01, 10000)]
        public decimal Price { get; set; }
       // [Range(0, int.MaxValue)]
        //public int Stock { get; set; }

        [MaxLength(250)]
        public string? StorageInstructions { get; set; }
        public bool IsPrescriptionRequired { get; set; } = false;
        
    }

    // DTO for updating an existing Drug
    public class UpdateDrugDto
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string Manufacturer { get; set; }
        [Required]
        
        public string Price { get; set; }
       // [Range(0, int.MaxValue)]
       // public int Stock { get; set; }

        [MaxLength(250)]
        public string? StorageInstructions { get; set; }
        public bool IsPrescriptionRequired { get; set; }
    }
}
