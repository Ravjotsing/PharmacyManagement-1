using System;
using System.ComponentModel.DataAnnotations;

namespace PharmacyManagement.DTO
{

    public class SaleDto
    {
        public int SalesId { get; set; }
        public DateTime Date { get; set; }
        public decimal TotalSales { get; set; }
       
        public int DrugId { get; set; }

       
        public string PaymentMethod { get; set; }
        
        
    }

    
    public class CreateSaleDto
    {
        [Required]
        public DateTime Date { get; set; }
        [Range(0.01, double.MaxValue)]
        public decimal TotalSales { get; set; }
        
        [Required]
        public int DrugId { get; set; }

        
        [Required]
        [MaxLength(50)]
        public string PaymentMethod { get; set; }
       
        
    }

    
    public class UpdateSaleDto
    {
        [Required]
        public DateTime Date { get; set; }
        [Range(0.01, double.MaxValue)]
        public decimal TotalSales { get; set; }
        
        [Required]
        public int DrugId { get; set; }


        [Required]
        [MaxLength(50)]
        public string PaymentMethod { get; set; }
        
        
    }
}