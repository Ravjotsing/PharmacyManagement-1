using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PharmacyManagement.Interface;
using PharmacyManagement.Models;
using PharmacyManagement.Data;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PharmacyManagement.Repository
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<SupplierRepository> _logger;

        public SupplierRepository(ApplicationDbContext context, ILogger<SupplierRepository> logger)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<IEnumerable<Supplier>> GetAllAsync()
        {
            _logger.LogInformation("Fetching all suppliers.");
            return await _context.Suppliers.AsNoTracking().ToListAsync();
        }

        public async Task<Supplier> AddAsync(Supplier supplier)
        {
            _logger.LogInformation("Adding supplier {Name}", supplier.Name);
            await _context.Suppliers.AddAsync(supplier);
            await _context.SaveChangesAsync();
            return supplier;
        }

        public async Task<bool> EmailExistsAsync(string email)
        {
            return await _context.Suppliers.AnyAsync(s => s.Email.ToLower() == email.ToLower());
        }
    }
}