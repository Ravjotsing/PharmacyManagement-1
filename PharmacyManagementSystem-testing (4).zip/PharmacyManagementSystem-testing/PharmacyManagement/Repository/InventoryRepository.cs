using Microsoft.EntityFrameworkCore;

using Microsoft.Extensions.Logging;

using PharmacyManagement.Interface;

using PharmacyManagement.Models;
using PharmacyManagement.Data;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Threading.Tasks;

namespace PharmacyManagement.Repository

{

    public class InventoryRepository : IInventoryRepository

    {

        private readonly ApplicationDbContext _context;

        private readonly ILogger<InventoryRepository> _logger;

        public InventoryRepository(ApplicationDbContext context, ILogger<InventoryRepository> logger)

        {

            _context = context;

            _logger = logger;

        }

        public async Task<IEnumerable<Inventory>> GetAllInventoryAsync()

        {

            _logger.LogInformation("Fetching all inventory items from DB.");

            return await _context.Inventory

                .Include(i => i.Drug)

                .Include(i => i.Supplier)

                .AsNoTracking()

                .ToListAsync();

        }

        public async Task<Inventory?> GetInventoryByDrugIdAsync(int drugId)

        {

            _logger.LogInformation("Fetching inventory for Drug ID: {DrugId}", drugId);

            return await _context.Inventory

                .Include(i => i.Drug)

                .Include(i => i.Supplier)

                .AsNoTracking()

                .FirstOrDefaultAsync(i => i.DrugId == drugId);

        }

        public async Task<Inventory?> GetInventoryByDrugNameAsync(string drugName)

        {

            _logger.LogInformation("Fetching inventory for Drug Name: {DrugName}", drugName);

            return await _context.Inventory

                .Include(i => i.Drug)

                .Include(i => i.Supplier)

                .AsNoTracking()

                .FirstOrDefaultAsync(i => i.Drug.Name.ToLower() == drugName.ToLower());

        }

        public async Task<bool> AddDrugToInventoryAsync(string drugName, int supplierId, int quantity)

        {

            var drug = await _context.Drugs.FirstOrDefaultAsync(d => d.Name.ToLower() == drugName.ToLower());

            if (drug == null)

                throw new KeyNotFoundException($"Drug '{drugName}' not found.");

            var supplierExists = await _context.Suppliers.AnyAsync(s => s.SupplierId == supplierId);

            if (!supplierExists)

                throw new KeyNotFoundException($"Supplier with ID {supplierId} not found.");

            var existingInventory = await _context.Inventory

                .FirstOrDefaultAsync(i => i.DrugId == drug.DrugId && i.SupplierId == supplierId);

            DateTime now = DateTime.UtcNow;

            if (existingInventory != null)

            {

                _logger.LogInformation("Updating existing inventory for Drug ID: {DrugId}", drug.DrugId);

                existingInventory.Quantity += quantity;

                existingInventory.LastRestockDate = now;

                _context.Inventory.Update(existingInventory);

            }

            else

            {

                _logger.LogInformation("Creating new inventory record for Drug ID: {DrugId}", drug.DrugId);

                await _context.Inventory.AddAsync(new Inventory

                {

                    DrugId = drug.DrugId,

                    SupplierId = supplierId,

                    Quantity = quantity,

                    LastRestockDate = now

                });

            }

            await _context.SaveChangesAsync();

            return true;

        }

        public async Task<bool> UpdateDrugQuantityAsync(string drugName, int newQuantity)

        {

            var inventoryItem = await _context.Inventory

                .Include(i => i.Drug)

                .FirstOrDefaultAsync(i => i.Drug.Name.ToLower() == drugName.ToLower());

            if (inventoryItem == null)

                throw new KeyNotFoundException($"Inventory for drug '{drugName}' not found.");

            inventoryItem.Quantity += newQuantity;

            _context.Inventory.Update(inventoryItem);

            await _context.SaveChangesAsync();

            _logger.LogInformation("Updated quantity for Drug: {DrugName} to {NewQuantity}", drugName, newQuantity);

            return true;

        }

    }
}