@echo off
echo Cleaning project for transfer...
echo.
echo Deleting node_modules (can reinstall with npm install)...
if exist "angular-frontend\node_modules" rmdir /s /q "angular-frontend\node_modules"

echo Deleting .NET bin folders...
if exist "PharmacyManagement\bin" rmdir /s /q "PharmacyManagement\bin"
if exist "PharmacyManagement.Tests\bin" rmdir /s /q "PharmacyManagement.Tests\bin"

echo Deleting .NET obj folders...
if exist "PharmacyManagement\obj" rmdir /s /q "PharmacyManagement\obj"
if exist "PharmacyManagement.Tests\obj" rmdir /s /q "PharmacyManagement.Tests\obj"

echo Deleting Angular dist folder...
if exist "angular-frontend\dist" rmdir /s /q "angular-frontend\dist"

echo.
echo Cleanup complete! Project is now ready to zip.
echo.
echo On the other laptop, run:
echo 1. cd PharmacyManagement
echo 2. dotnet restore
echo 3. cd ..\angular-frontend
echo 4. npm install
echo.
pause