# Pharmacy Management Frontend

Angular frontend for the Pharmacy Management System API.

## Features

- **Authentication**: Login for users and admin
- **Drug Management**: View, add, update, delete drugs (admin only)
- **Inventory Management**: View and manage inventory
- **Responsive Design**: Clean, minimal UI

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm start
   ```

3. Open browser to `http://localhost:4200`

## API Integration

The frontend connects to these API endpoints:

- **Auth**: `/api/authentication/*`
- **Drugs**: `/api/drugs/*`
- **Inventory**: `/api/inventory/*`

## Components

- **LoginComponent**: User/admin authentication
- **DrugListComponent**: CRUD operations for drugs
- **AppComponent**: Main navigation and layout

## Services

- **AuthService**: Authentication and token management
- **DrugService**: Drug CRUD operations
- **InventoryService**: Inventory management

## Usage

1. Login with user credentials or admin credentials
2. Navigate to drugs section to manage pharmacy inventory
3. Add, edit, or delete drugs (admin only)
4. View drug listings and inventory status

## Configuration

Update API base URLs in services if your backend runs on different ports:
- Default: `https://localhost:7000`