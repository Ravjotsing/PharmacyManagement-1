import { Routes } from '@angular/router';
import { LoginComponent } from './components/login.component';
import { LandingComponent } from './components/landing.component';
import { RegisterComponent } from './components/register.component';
import { DrugListComponent } from './components/drug-list.component';
import { SalesReportComponent } from './components/sales-report.component';
import { AdminDashboardComponent } from './components/admin-dashboard.component';
import { AdminDashboardSimpleComponent } from './components/admin-dashboard-simple.component';
import { DrugManagementComponent } from './components/drug-management.component';
import { InventoryManagementComponent } from './components/inventory-management.component';
import { OrdersManagementComponent } from './components/orders-management.component';

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'admin/dashboard', component: AdminDashboardSimpleComponent },
  { path: 'admin/drugs', component: DrugManagementComponent },
  { path: 'admin/inventory', component: InventoryManagementComponent },
  { path: 'admin/orders', component: OrdersManagementComponent },
  { path: 'drugs', component: DrugListComponent },
  { path: 'sales-report', component: SalesReportComponent },
  { path: 'admin/sales-report', component: SalesReportComponent }
];