import { Component, OnInit, OnDestroy } from '@angular/core';
import { NotificationService, Notification } from '../services/notification.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-toast-notification',
  template: `
    <div class="toast-container">
      <div class="toast" 
           *ngFor="let notification of notifications" 
           [class]="'toast-' + notification.type">
        <div class="toast-icon">
          <span *ngIf="notification.type === 'success'">✅</span>
          <span *ngIf="notification.type === 'error'">❌</span>
          <span *ngIf="notification.type === 'warning'">⚠️</span>
          <span *ngIf="notification.type === 'info'">ℹ️</span>
        </div>
        <div class="toast-content">
          <p class="toast-message">{{notification.message}}</p>
          <span class="toast-time">{{notification.time}}</span>
        </div>
        <button class="toast-close" (click)="closeToast(notification.id)">×</button>
      </div>
    </div>
  `,
  styles: [`
    .toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-width: 400px;
    }

    .toast {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 16px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.2);
      animation: slideIn 0.3s ease;
    }

    .toast-success {
      background: rgba(76, 175, 80, 0.9);
      color: white;
    }

    .toast-error {
      background: rgba(244, 67, 54, 0.9);
      color: white;
    }

    .toast-warning {
      background: rgba(255, 152, 0, 0.9);
      color: white;
    }

    .toast-info {
      background: rgba(33, 150, 243, 0.9);
      color: white;
    }

    .toast-icon {
      font-size: 20px;
      flex-shrink: 0;
    }

    .toast-content {
      flex: 1;
    }

    .toast-message {
      margin: 0 0 4px 0;
      font-weight: 500;
      line-height: 1.4;
    }

    .toast-time {
      font-size: 12px;
      opacity: 0.8;
    }

    .toast-close {
      background: none;
      border: none;
      color: inherit;
      font-size: 20px;
      cursor: pointer;
      padding: 0;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: background-color 0.3s ease;
    }

    .toast-close:hover {
      background-color: rgba(255,255,255,0.2);
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(100px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @media (max-width: 480px) {
      .toast-container {
        left: 20px;
        right: 20px;
        max-width: none;
      }
    }
  `]
})
export class ToastNotificationComponent implements OnInit, OnDestroy {
  notifications: Notification[] = [];
  private subscription?: Subscription;

  constructor(private notificationService: NotificationService) {}

  ngOnInit() {
    this.subscription = this.notificationService.notifications$.subscribe(
      notifications => {
        // Only show notifications with autoClose = true for toast
        this.notifications = notifications.filter(n => n.autoClose);
      }
    );
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  closeToast(id: number) {
    this.notificationService.removeNotification(id);
  }
}