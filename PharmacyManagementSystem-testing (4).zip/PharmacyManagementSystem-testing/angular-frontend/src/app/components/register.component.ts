import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  template: `
    <div class="register-container">
      <div class="register-card">
        <div class="register-header">
          <img src="https://cdn-icons-png.flaticon.com/512/883/883356.png" alt="Pharmacy" class="logo-img">
          <h1>Create Account</h1>
          <p>Join our pharmacy system</p>
        </div>
        
        <div class="register-form">
          <div class="input-group">
            <input 
              type="text" 
              [(ngModel)]="userData.name" 
              placeholder="Full Name"
              required>
          </div>
          
          <div class="input-group">
            <input 
              type="email" 
              [(ngModel)]="userData.email" 
              placeholder="Email Address"
              required>
          </div>
          
          <div class="input-group">
            <input 
              type="password" 
              [(ngModel)]="userData.password" 
              placeholder="Password"
              required>
          </div>
          
          <button class="register-btn" (click)="register()">
            Create Account
          </button>
          
          <div class="login-link">
            <p>Already have an account? <a (click)="goToLogin()">Login here</a></p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
    }
    
    .register-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      overflow: hidden;
      width: 100%;
      max-width: 400px;
    }
    
    .register-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      text-align: center;
    }
    
    .register-header h1 {
      margin: 0 0 10px 0;
      font-size: 1.8rem;
    }
    
    .register-header p {
      margin: 0;
      opacity: 0.9;
    }
    
    .logo-img {
      width: 60px;
      height: 60px;
      margin-bottom: 15px;
      filter: brightness(0) invert(1);
    }
    
    .register-form {
      padding: 30px;
    }
    
    .input-group {
      margin-bottom: 20px;
    }
    
    input {
      width: 100%;
      padding: 12px 15px;
      border: 2px solid #e9ecef;
      border-radius: 8px;
      font-size: 1rem;
      box-sizing: border-box;
    }
    
    input:focus {
      outline: none;
      border-color: #667eea;
    }
    
    .register-btn {
      width: 100%;
      padding: 12px 20px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      color: white;
      background: #28a745;
      margin-bottom: 20px;
    }
    
    .register-btn:hover {
      opacity: 0.9;
    }
    
    .login-link {
      text-align: center;
    }
    
    .login-link a {
      color: #667eea;
      cursor: pointer;
      text-decoration: underline;
    }
  `]
})
export class RegisterComponent {
  userData = {
    name: '',
    email: '',
    password: ''
  };
  
  constructor(private router: Router, private authService: AuthService) {}

  register() {
    this.authService.register(this.userData).subscribe({
      next: () => {
        alert('Registration successful! Please login.');
        this.router.navigate(['/login']);
      },
      error: (error) => {
        console.error('Registration failed:', error);
        alert('Registration failed: ' + error.message);
      }
    });
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }
}