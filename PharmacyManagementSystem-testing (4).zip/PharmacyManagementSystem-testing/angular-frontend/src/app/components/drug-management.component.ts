import { Component, OnInit } from '@angular/core';
import { DrugService } from '../services/drug.service';
import { NotificationService } from '../services/notification.service';
import { Drug } from '../models/drug.model';

@Component({
  selector: 'app-drug-management',
  templateUrl: './drug-management.component.html',
  styleUrls: ['./drug-management.component.css']
})
export class DrugManagementComponent implements OnInit {
  drugs: Drug[] = [];
  loading = false;

  filteredDrugs = [...this.drugs];
  searchTerm = '';
  selectedCategory = '';
  showAddForm = false;
  editingDrug: any = null;

  newDrug = {
    name: '',
    manufacturer: '',
    price: 0,
    stock: 0,
    storageInstructions: '',
    isPrescriptionRequired: false
  };

  categories = ['Pain Relief', 'Anti-inflammatory', 'Antibiotic', 'Vitamin', 'Other'];

  constructor(
    private drugService: DrugService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.loadDrugs();
  }

  loadDrugs() {
    this.loading = true;
    this.drugService.getAllDrugs().subscribe({
      next: (drugs) => {
        this.drugs = drugs;
        this.filterDrugs();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading drugs:', error);
        this.notificationService.showError('Failed to load drugs');
        this.loading = false;
      }
    });
  }

  filterDrugs() {
    this.filteredDrugs = this.drugs.filter(drug => {
      const matchesSearch = drug.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
                           drug.manufacturer.toLowerCase().includes(this.searchTerm.toLowerCase());
      return matchesSearch;
    });
  }

  onSearchChange() {
    this.filterDrugs();
  }

  onCategoryChange() {
    this.filterDrugs();
  }

  addDrug() {
    if (this.newDrug.name && this.newDrug.manufacturer) {
      this.loading = true;
      const drugData = {
        name: this.newDrug.name,
        manufacturer: this.newDrug.manufacturer,
        price: this.newDrug.price,
        stock: this.newDrug.stock,
        storageInstructions: '',
        isPrescriptionRequired: false
      };
      
      this.drugService.addDrug(drugData).subscribe({
        next: (drug) => {
          this.drugs.push(drug);
          this.resetForm();
          this.filterDrugs();
          this.notificationService.showSuccess('Drug added successfully');
          this.loading = false;
        },
        error: (error) => {
          console.error('Error adding drug:', error);
          this.notificationService.showError('Failed to add drug');
          this.loading = false;
        }
      });
    }
  }

  editDrug(drug: any) {
    this.editingDrug = { ...drug };
    this.showAddForm = true;
    this.newDrug = { ...drug };
  }

  updateDrug() {
    if (this.editingDrug) {
      this.loading = true;
      const drugData = {
        drugId: this.editingDrug.drugId,
        name: this.newDrug.name,
        manufacturer: this.newDrug.manufacturer,
        price: this.newDrug.price,
        stock: this.newDrug.stock,
        storageInstructions: this.editingDrug.storageInstructions || '',
        isPrescriptionRequired: this.editingDrug.isPrescriptionRequired || false
      };
      
      this.drugService.updateDrug(this.editingDrug.drugId, drugData).subscribe({
        next: (drug) => {
          const index = this.drugs.findIndex(d => d.drugId === this.editingDrug.drugId);
          if (index !== -1) {
            this.drugs[index] = drug;
          }
          this.resetForm();
          this.filterDrugs();
          this.notificationService.showSuccess('Drug updated successfully');
          this.loading = false;
        },
        error: (error) => {
          console.error('Error updating drug:', error);
          this.notificationService.showError('Failed to update drug');
          this.loading = false;
        }
      });
    }
  }

  deleteDrug(id: number) {
    if (confirm('Are you sure you want to delete this drug?')) {
      this.loading = true;
      this.drugService.deleteDrug(id).subscribe({
        next: () => {
          this.drugs = this.drugs.filter(drug => drug.drugId !== id);
          this.filterDrugs();
          this.notificationService.showSuccess('Drug deleted successfully');
          this.loading = false;
        },
        error: (error) => {
          console.error('Error deleting drug:', error);
          this.notificationService.showError('Failed to delete drug');
          this.loading = false;
        }
      });
    }
  }

  resetForm() {
    this.newDrug = {
      name: '',
      manufacturer: '',
      price: 0,
      stock: 0,
      storageInstructions: '',
      isPrescriptionRequired: false
    };
    this.showAddForm = false;
    this.editingDrug = null;
  }

  getStockStatus(stock: number): string {
    if (stock < 50) return 'low';
    if (stock < 100) return 'medium';
    return 'high';
  }
}