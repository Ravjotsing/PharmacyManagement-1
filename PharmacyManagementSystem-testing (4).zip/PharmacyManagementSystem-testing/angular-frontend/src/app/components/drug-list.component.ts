import { Component } from '@angular/core';

@Component({
  selector: 'app-drug-list',
  templateUrl: './drug-list.component.html'
})
export class DrugListComponent {
  drugs = [
    { drugId: 1, name: 'Aspirin', manufacturer: 'Bayer', price: 12.99 },
    { drugId: 2, name: 'Ibuprofen', manufacturer: 'Advil', price: 8.50 }
  ];
}