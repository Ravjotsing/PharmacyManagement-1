import { Component, OnInit } from '@angular/core';
import { SalesService } from '../services/sales.service';

export interface SalesReportRequest {
  startDate?: string;
  endDate?: string;
  drugId?: number;
  paymentMethod?: string;
  format: ReportFormat;
}

export enum ReportFormat {
  CSV = 1,
  Excel = 2,
  PDF = 3
}

@Component({
  selector: 'app-sales-report',
  templateUrl: './sales-report.component.html'
})
export class SalesReportComponent implements OnInit {
  reportRequest: SalesReportRequest = {
    format: ReportFormat.CSV
  };

  ReportFormat = ReportFormat;
  isLoading = false;
  drugs: any[] = [];

  constructor(private salesService: SalesService) {}

  ngOnInit() {
    this.loadDrugs();
  }

  loadDrugs() {
    // Load drugs for dropdown - you'll need to implement this in your drug service
    // this.drugService.getAllDrugs().subscribe(drugs => this.drugs = drugs);
  }

  downloadReport() {
    if (this.isLoading) return;
    
    this.isLoading = true;
    
    this.salesService.downloadSalesReport(this.reportRequest).subscribe({
      next: (response) => {
        this.downloadFile(response, this.getFileName());
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error downloading report:', error);
        alert('Error downloading report. Please try again.');
        this.isLoading = false;
      }
    });
  }

  private downloadFile(data: Blob, filename: string) {
    const blob = new Blob([data]);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  private getFileName(): string {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const extension = this.getFileExtension();
    return `SalesReport_${timestamp}.${extension}`;
  }

  private getFileExtension(): string {
    switch (this.reportRequest.format) {
      case ReportFormat.CSV: return 'csv';
      case ReportFormat.Excel: return 'xlsx';
      case ReportFormat.PDF: return 'pdf';
      default: return 'txt';
    }
  }

  clearFilters() {
    this.reportRequest = {
      format: ReportFormat.CSV
    };
  }
}