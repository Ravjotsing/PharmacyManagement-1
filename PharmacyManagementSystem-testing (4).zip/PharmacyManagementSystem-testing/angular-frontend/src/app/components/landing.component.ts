import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing',
  template: `
    <div class="landing-container">
      <div class="hero-section">
        <img src="https://cdn-icons-png.flaticon.com/512/883/883356.png" alt="Pharmacy" class="hero-logo">
        <h1>PharmaCare Management System</h1>
        <p>Your trusted healthcare management platform</p>
        
        <div class="action-buttons">
          <button class="btn-primary" (click)="goToLogin()">Login</button>
          <button class="btn-secondary" (click)="goToRegister()">Register</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .landing-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
    }
    
    .hero-section {
      text-align: center;
      color: white;
      max-width: 500px;
    }
    
    .hero-logo {
      width: 100px;
      height: 100px;
      margin-bottom: 30px;
      filter: brightness(0) invert(1);
    }
    
    h1 {
      font-size: 3rem;
      margin-bottom: 20px;
      font-weight: 700;
    }
    
    p {
      font-size: 1.2rem;
      margin-bottom: 40px;
      opacity: 0.9;
    }
    
    .action-buttons {
      display: flex;
      gap: 20px;
      justify-content: center;
    }
    
    button {
      padding: 15px 30px;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s;
    }
    
    button:hover {
      transform: translateY(-2px);
    }
    
    .btn-primary {
      background: white;
      color: #667eea;
    }
    
    .btn-secondary {
      background: transparent;
      color: white;
      border: 2px solid white;
    }
  `]
})
export class LandingComponent {
  constructor(private router: Router) {}

  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }
}