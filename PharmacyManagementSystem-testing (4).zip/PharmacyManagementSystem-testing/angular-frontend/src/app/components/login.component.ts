import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  credentials = {
    email: 'admin@pharmacy.com',
    password: 'Admin123!'
  };
  
  isLoading = false;
  
  constructor(private router: Router) {}

  async loginAsAdmin() {
    if (!this.validateForm()) return;
    
    this.isLoading = true;
    
    // Simulate API call delay
    setTimeout(() => {
      this.isLoading = false;
      this.router.navigate(['/admin/dashboard']);
    }, 1000);
  }

  async loginAsUser() {
    if (!this.validateForm()) return;
    
    this.isLoading = true;
    
    // Simulate API call delay
    setTimeout(() => {
      this.isLoading = false;
      this.router.navigate(['/drugs']);
    }, 1000);
  }
  
  private validateForm(): boolean {
    if (!this.credentials.email || !this.credentials.password) {
      alert('Please fill in all fields');
      return false;
    }
    
    if (!this.isValidEmail(this.credentials.email)) {
      alert('Please enter a valid email address');
      return false;
    }
    
    return true;
  }
  
  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  fillAdminCredentials() {
    this.credentials.email = 'admin@pharmacy.com';
    this.credentials.password = 'Admin123!';
  }
  
  fillUserCredentials() {
    this.credentials.email = 'user@pharmacy.com';
    this.credentials.password = 'User123!';
  }
}