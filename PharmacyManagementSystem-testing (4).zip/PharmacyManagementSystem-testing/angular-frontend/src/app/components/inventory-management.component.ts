import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-management',
  templateUrl: './inventory-management.component.html',
  styleUrls: ['./inventory-management.component.css']
})
export class InventoryManagementComponent implements OnInit {
  inventoryItems = [
    { id: 1, drugName: 'Aspirin', currentStock: 150, minStock: 50, maxStock: 500, lastRestocked: '2024-01-15', supplier: 'PharmaCorp', location: 'A-1-01' },
    { id: 2, drugName: 'Ibuprofen', currentStock: 25, minStock: 50, maxStock: 300, lastRestocked: '2024-01-10', supplier: 'MediLab', location: 'A-1-02' },
    { id: 3, drugName: 'Paracetamol', currentStock: 300, minStock: 100, maxStock: 600, lastRestocked: '2024-01-20', supplier: 'HealthPlus', location: 'A-2-01' }
  ];

  filteredItems = [...this.inventoryItems];
  searchTerm = '';
  stockFilter = '';
  showRestockForm = false;
  selectedItem: any = null;

  restockData = {
    quantity: 0,
    supplier: '',
    cost: 0,
    notes: ''
  };

  ngOnInit() {
    this.filterItems();
  }

  filterItems() {
    this.filteredItems = this.inventoryItems.filter(item => {
      const matchesSearch = item.drugName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
                           item.supplier.toLowerCase().includes(this.searchTerm.toLowerCase());
      
      let matchesStock = true;
      if (this.stockFilter === 'low') {
        matchesStock = item.currentStock <= item.minStock;
      } else if (this.stockFilter === 'normal') {
        matchesStock = item.currentStock > item.minStock && item.currentStock < item.maxStock * 0.8;
      } else if (this.stockFilter === 'high') {
        matchesStock = item.currentStock >= item.maxStock * 0.8;
      }
      
      return matchesSearch && matchesStock;
    });
  }

  onSearchChange() {
    this.filterItems();
  }

  onStockFilterChange() {
    this.filterItems();
  }

  getStockStatus(item: any): string {
    if (item.currentStock <= item.minStock) return 'critical';
    if (item.currentStock <= item.minStock * 1.5) return 'low';
    if (item.currentStock >= item.maxStock * 0.8) return 'high';
    return 'normal';
  }

  getStockPercentage(item: any): number {
    return (item.currentStock / item.maxStock) * 100;
  }

  openRestockForm(item: any) {
    this.selectedItem = item;
    this.restockData = {
      quantity: 0,
      supplier: item.supplier,
      cost: 0,
      notes: ''
    };
    this.showRestockForm = true;
  }

  restockItem() {
    if (this.selectedItem && this.restockData.quantity > 0) {
      this.selectedItem.currentStock += this.restockData.quantity;
      this.selectedItem.lastRestocked = new Date().toISOString().split('T')[0];
      this.closeRestockForm();
      this.filterItems();
    }
  }

  closeRestockForm() {
    this.showRestockForm = false;
    this.selectedItem = null;
    this.restockData = {
      quantity: 0,
      supplier: '',
      cost: 0,
      notes: ''
    };
  }

  getLowStockCount(): number {
    return this.inventoryItems.filter(item => item.currentStock <= item.minStock).length;
  }

  getTotalValue(): number {
    // This would typically come from the backend with actual prices
    return this.inventoryItems.reduce((total, item) => total + (item.currentStock * 10), 0);
  }
}