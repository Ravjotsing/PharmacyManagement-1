import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard-simple',
  template: `
    <div class="admin-layout">
      <!-- Sidebar -->
      <nav class="sidebar">
        <div class="sidebar-header">
          <div class="logo">
            <span class="logo-icon">🏥</span>
            <span class="logo-text">PharmaCare</span>
          </div>
        </div>
        
        <div class="sidebar-menu">
          <div class="menu-section">
            <h4>Main Menu</h4>
            <ul class="menu-items">
              <li class="menu-item active">
                <a href="#" class="menu-link">
                  <span class="menu-icon">🏠</span>
                  <span class="menu-text">Dashboard</span>
                </a>
              </li>
              <li class="menu-item" *ngFor="let feature of adminFeatures">
                <a (click)="navigateToFeature(feature.route)" class="menu-link">
                  <span class="menu-icon">{{feature.icon}}</span>
                  <span class="menu-text">{{feature.title}}</span>
                  <span class="menu-badge" *ngIf="feature.count > 0">{{feature.count}}</span>
                </a>
              </li>
            </ul>
          </div>
          
          <div class="menu-section">
            <h4>Account</h4>
            <ul class="menu-items">
              <li class="menu-item">
                <a href="#" class="menu-link">
                  <span class="menu-icon">⚙️</span>
                  <span class="menu-text">Settings</span>
                </a>
              </li>
              <li class="menu-item">
                <a (click)="logout()" class="menu-link">
                  <span class="menu-icon">🚪</span>
                  <span class="menu-text">Logout</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="main-content">
        <!-- Header -->
        <header class="header">
          <div class="header-left">
            <h1 class="page-title">Enhanced Admin Dashboard</h1>
            <div class="search-container">
              <input type="text" 
                     class="search-input" 
                     placeholder="Search anything..."
                     [(ngModel)]="searchQuery">
              <span class="search-icon">🔍</span>
            </div>
          </div>
          <div class="header-right">
            <button class="refresh-btn" (click)="refreshData()" title="Refresh Data">
              <span class="refresh-icon">🔄</span>
            </button>
            <div class="notifications-container">
              <button class="notifications-btn" (click)="toggleNotifications()">
                <span class="notification-icon">🔔</span>
                <span class="notification-badge" *ngIf="notifications.length > 0">
                  {{notifications.length}}
                </span>
              </button>
            </div>
            <div class="user-info">
              <span class="user-avatar">👤</span>
              <span class="user-name">Admin User</span>
            </div>
          </div>
        </header>

        <!-- Dashboard Content -->
        <div class="dashboard-content">
          <!-- Stats Cards -->
          <div class="stats-grid">
            <div class="stat-card enhanced">
              <div class="stat-icon">💊</div>
              <div class="stat-info">
                <h3>Total Drugs</h3>
                <p class="stat-number">{{stats.totalDrugs}}</p>
                <div class="stat-trend positive">
                  <span class="trend-icon">↗️</span>
                  <span class="trend-text">+5.2%</span>
                </div>
              </div>
            </div>
            <div class="stat-card enhanced">
              <div class="stat-icon">📦</div>
              <div class="stat-info">
                <h3>Inventory Items</h3>
                <p class="stat-number">{{stats.inventoryItems}}</p>
                <div class="stat-trend positive">
                  <span class="trend-icon">↗️</span>
                  <span class="trend-text">+2.1%</span>
                </div>
              </div>
            </div>
            <div class="stat-card enhanced">
              <div class="stat-icon">💰</div>
              <div class="stat-info">
                <h3>Today's Sales</h3>
                <p class="stat-number">\${{stats.todaysSales}}</p>
                <div class="stat-trend positive">
                  <span class="trend-icon">↗️</span>
                  <span class="trend-text">+12.5%</span>
                </div>
              </div>
            </div>
            <div class="stat-card enhanced">
              <div class="stat-icon">🛒</div>
              <div class="stat-info">
                <h3>Pending Orders</h3>
                <p class="stat-number">{{stats.pendingOrders}}</p>
                <div class="stat-trend negative">
                  <span class="trend-icon">↘️</span>
                  <span class="trend-text">-3.2%</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Feature Cards -->
          <div class="features-section">
            <h2 class="section-title">Management Features</h2>
            <div class="features-grid">
              <div class="feature-card enhanced" 
                   *ngFor="let feature of adminFeatures" 
                   (click)="navigateToFeature(feature.route)">
                <div class="feature-header">
                  <span class="feature-icon">{{feature.icon}}</span>
                  <h3 class="feature-title">{{feature.title}}</h3>
                </div>
                <p class="feature-description">{{feature.description}}</p>
                <div class="feature-action">
                  <button class="action-btn enhanced">
                    Access →
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Quick Actions -->
          <div class="quick-actions">
            <h2 class="section-title">Quick Actions</h2>
            <div class="actions-grid">
              <button class="quick-action-btn enhanced" 
                      *ngFor="let action of quickActions"
                      (click)="executeQuickAction(action.id)">
                <span class="action-icon">{{action.icon}}</span>
                <span>{{action.title}}</span>
              </button>
            </div>
          </div>

          <!-- Recent Activity -->
          <div class="recent-activity">
            <h2 class="section-title">Recent Activity</h2>
            <div class="activity-list">
              <div class="activity-item enhanced" *ngFor="let activity of recentActivities">
                <div class="activity-icon">{{activity.icon}}</div>
                <div class="activity-content">
                  <div class="activity-main">
                    <span class="activity-action">{{activity.action}}</span>
                    <span class="activity-item-name">{{activity.item}}</span>
                  </div>
                  <div class="activity-meta">
                    <span class="activity-user">by {{activity.user}}</span>
                    <span class="activity-time">{{activity.time}}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  `,
  styles: [`
    .admin-layout {
      display: flex;
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      width: 280px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      color: white;
      padding: 20px;
      box-shadow: 2px 0 20px rgba(0,0,0,0.1);
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 30px;
      padding-bottom: 20px;
      border-bottom: 1px solid rgba(255,255,255,0.2);
    }

    .logo-icon {
      font-size: 32px;
    }

    .logo-text {
      font-size: 24px;
      font-weight: bold;
    }

    .menu-section h4 {
      margin-bottom: 15px;
      font-size: 12px;
      text-transform: uppercase;
      opacity: 0.8;
      letter-spacing: 1px;
    }

    .menu-items {
      list-style: none;
      padding: 0;
      margin: 0 0 30px 0;
    }

    .menu-link {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      margin: 4px 0;
      transition: all 0.3s ease;
      cursor: pointer;
    }

    .menu-link:hover {
      background: rgba(255,255,255,0.2);
      transform: translateX(5px);
    }

    .menu-item.active .menu-link {
      background: rgba(255,255,255,0.3);
    }

    .menu-icon {
      font-size: 18px;
      margin-right: 12px;
    }

    .menu-badge {
      background: #ff4757;
      color: white;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 10px;
      font-weight: bold;
    }

    .main-content {
      flex: 1;
      background: rgba(255, 255, 255, 0.95);
      margin: 20px;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,0.1);
    }

    .header {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      padding: 20px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .header-left {
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .page-title {
      font-size: 28px;
      font-weight: 700;
      color: #333;
      margin: 0;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .search-container {
      position: relative;
    }

    .search-input {
      padding: 12px 40px 12px 16px;
      border: 2px solid #e9ecef;
      border-radius: 25px;
      width: 300px;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .search-input:focus {
      outline: none;
      border-color: #667eea;
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      width: 350px;
    }

    .search-icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #666;
    }

    .header-right {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .refresh-btn, .notifications-btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      color: white;
      padding: 12px;
      border-radius: 50%;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
    }

    .refresh-btn:hover, .notifications-btn:hover {
      transform: scale(1.1);
      box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    }

    .notification-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background: #ff4757;
      color: white;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 10px;
      font-weight: bold;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 16px;
      background: #f8f9fa;
      border-radius: 25px;
    }

    .dashboard-content {
      padding: 30px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 25px;
      margin-bottom: 40px;
    }

    .stat-card.enhanced {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
      display: flex;
      align-items: center;
      gap: 20px;
      transition: all 0.4s ease;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .stat-card.enhanced:hover {
      transform: translateY(-10px) scale(1.02);
      box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    }

    .stat-icon {
      font-size: 50px;
      padding: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
    }

    .stat-info h3 {
      margin: 0 0 8px 0;
      font-size: 14px;
      color: #666;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: 600;
    }

    .stat-number {
      margin: 0 0 8px 0;
      font-size: 36px;
      font-weight: 700;
      color: #333;
    }

    .stat-trend {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      font-weight: 600;
    }

    .stat-trend.positive {
      color: #4caf50;
    }

    .stat-trend.negative {
      color: #f44336;
    }

    .section-title {
      font-size: 24px;
      font-weight: 600;
      color: #333;
      margin-bottom: 25px;
      padding-bottom: 10px;
      border-bottom: 3px solid #667eea;
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 25px;
      margin-bottom: 40px;
    }

    .feature-card.enhanced {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
      transition: all 0.4s ease;
      cursor: pointer;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .feature-card.enhanced:hover {
      transform: translateY(-10px) scale(1.02);
      box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    }

    .feature-header {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 15px;
    }

    .feature-icon {
      font-size: 36px;
      padding: 15px;
      background: rgba(102, 126, 234, 0.1);
      border-radius: 15px;
    }

    .feature-title {
      margin: 0;
      font-size: 20px;
      font-weight: 600;
      color: #333;
    }

    .feature-description {
      color: #666;
      margin-bottom: 20px;
      line-height: 1.6;
    }

    .action-btn.enhanced {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 25px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .action-btn.enhanced:hover {
      transform: translateX(5px);
      box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    }

    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .quick-action-btn.enhanced {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border: 2px solid transparent;
      border-radius: 15px;
      padding: 25px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      transition: all 0.4s ease;
      font-weight: 600;
      color: #333;
    }

    .quick-action-btn.enhanced:hover {
      border-color: #667eea;
      background: rgba(102, 126, 234, 0.1);
      transform: translateY(-5px) scale(1.02);
      box-shadow: 0 15px 40px rgba(102, 126, 234, 0.2);
    }

    .action-icon {
      font-size: 32px;
      padding: 15px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 15px;
      transition: all 0.3s ease;
    }

    .recent-activity {
      margin-bottom: 40px;
    }

    .activity-list {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .activity-item.enhanced {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 20px 0;
      border-bottom: 1px solid rgba(0,0,0,0.1);
      transition: all 0.3s ease;
    }

    .activity-item.enhanced:hover {
      background: rgba(102, 126, 234, 0.05);
      border-radius: 10px;
      padding: 20px;
      margin: 0 -20px;
    }

    .activity-icon {
      font-size: 28px;
      width: 50px;
      height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 15px;
      color: white;
    }

    .activity-main {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }

    .activity-action {
      font-weight: 600;
      color: #333;
    }

    .activity-item-name {
      color: #667eea;
      font-weight: 500;
    }

    .activity-meta {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 12px;
      color: #666;
    }
  `]
})
export class AdminDashboardSimpleComponent {
  searchQuery = '';
  notifications = [
    { message: 'New order received', type: 'success' },
    { message: 'Low stock alert', type: 'warning' }
  ];
  
  stats = {
    totalDrugs: 1234,
    inventoryItems: 856,
    todaysSales: 12450,
    pendingOrders: 23
  };
  
  adminFeatures = [
    {
      title: 'Manage Drugs',
      description: 'Add, edit, and manage pharmaceutical products with enhanced interface',
      icon: '💊',
      route: '/admin/drugs',
      count: 1234
    },
    {
      title: 'Manage Inventory',
      description: 'Track stock levels with real-time updates and alerts',
      icon: '📦',
      route: '/admin/inventory',
      count: 856
    },
    {
      title: 'Sales Reports',
      description: 'View interactive sales analytics and generate reports',
      icon: '📊',
      route: '/admin/sales-report',
      count: 0
    },
    {
      title: 'Manage Orders',
      description: 'Process and track customer orders efficiently',
      icon: '🛒',
      route: '/admin/orders',
      count: 23
    }
  ];

  quickActions = [
    { id: 'add-drug', title: 'Add New Drug', icon: '➕' },
    { id: 'generate-report', title: 'Generate Report', icon: '📋' },
    { id: 'search-inventory', title: 'Search Inventory', icon: '🔍' },
    { id: 'contact-supplier', title: 'Contact Supplier', icon: '📞' }
  ];

  recentActivities = [
    { action: 'Drug Added', item: 'Aspirin 500mg', user: 'Admin', time: '10 min ago', icon: '➕' },
    { action: 'Order Processed', item: 'Order #1234', user: 'Admin', time: '15 min ago', icon: '✅' },
    { action: 'Stock Updated', item: 'Paracetamol', user: 'Admin', time: '20 min ago', icon: '📦' },
    { action: 'Report Generated', item: 'Sales Report', user: 'Admin', time: '1 hour ago', icon: '📊' }
  ];

  constructor(private router: Router) {}

  navigateToFeature(route: string) {
    this.router.navigate([route]);
  }

  executeQuickAction(actionId: string) {
    switch (actionId) {
      case 'add-drug':
        this.router.navigate(['/admin/drugs']);
        break;
      case 'generate-report':
        this.router.navigate(['/admin/sales-report']);
        break;
      case 'search-inventory':
        this.router.navigate(['/admin/inventory']);
        break;
      case 'contact-supplier':
        alert('Contacting supplier...');
        break;
    }
  }

  toggleNotifications() {
    alert('Notifications: ' + this.notifications.length + ' new items');
  }

  refreshData() {
    // Simulate data refresh
    this.stats.todaysSales += Math.floor(Math.random() * 1000);
    alert('Data refreshed successfully!');
  }

  logout() {
    this.router.navigate(['/login']);
  }
}