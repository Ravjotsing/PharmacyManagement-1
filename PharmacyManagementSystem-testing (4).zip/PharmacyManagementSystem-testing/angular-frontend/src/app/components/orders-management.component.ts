import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-management',
  templateUrl: './orders-management.component.html',
  styleUrls: ['./orders-management.component.css']
})
export class OrdersManagementComponent implements OnInit {
  orders = [
    { 
      id: 'ORD-001', 
      customerName: 'John Doe', 
      items: [{ name: 'Aspirin', quantity: 2, price: 12.99 }], 
      total: 25.98, 
      status: 'pending', 
      date: '2024-01-20',
      phone: '+1-555-0123'
    },
    { 
      id: 'ORD-002', 
      customerName: 'Jane Smith', 
      items: [{ name: 'Ibuprofen', quantity: 1, price: 8.50 }], 
      total: 8.50, 
      status: 'completed', 
      date: '2024-01-19',
      phone: '+1-555-0124'
    },
    { 
      id: 'ORD-003', 
      customerName: 'Bob Johnson', 
      items: [{ name: 'Paracetamol', quantity: 3, price: 6.75 }], 
      total: 20.25, 
      status: 'processing', 
      date: '2024-01-21',
      phone: '+1-555-0125'
    }
  ];

  filteredOrders = [...this.orders];
  searchTerm = '';
  statusFilter = '';
  selectedOrder: any = null;
  showOrderDetails = false;

  ngOnInit() {
    this.filterOrders();
  }

  filterOrders() {
    this.filteredOrders = this.orders.filter(order => {
      const matchesSearch = order.id.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
                           order.customerName.toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchesStatus = !this.statusFilter || order.status === this.statusFilter;
      return matchesSearch && matchesStatus;
    });
  }

  onSearchChange() {
    this.filterOrders();
  }

  onStatusFilterChange() {
    this.filterOrders();
  }

  viewOrderDetails(order: any) {
    this.selectedOrder = order;
    this.showOrderDetails = true;
  }

  closeOrderDetails() {
    this.showOrderDetails = false;
    this.selectedOrder = null;
  }

  updateOrderStatus(orderId: string, newStatus: string) {
    const order = this.orders.find(o => o.id === orderId);
    if (order) {
      order.status = newStatus;
      this.filterOrders();
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'pending': return 'status-pending';
      case 'processing': return 'status-processing';
      case 'completed': return 'status-completed';
      case 'cancelled': return 'status-cancelled';
      default: return '';
    }
  }

  getOrderTotal(order: any): number {
    return order.items.reduce((total: number, item: any) => total + (item.quantity * item.price), 0);
  }

  getPendingOrdersCount(): number {
    return this.orders.filter(order => order.status === 'pending').length;
  }

  getTodaysRevenue(): number {
    const today = new Date().toISOString().split('T')[0];
    return this.orders
      .filter(order => order.date === today && order.status === 'completed')
      .reduce((total, order) => total + order.total, 0);
  }
}