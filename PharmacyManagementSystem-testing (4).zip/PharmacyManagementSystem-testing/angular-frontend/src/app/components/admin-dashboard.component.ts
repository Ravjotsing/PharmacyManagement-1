import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent {
  searchQuery = '';
  showNotifications = false;
  
  stats = {
    totalDrugs: 1234,
    inventoryItems: 856,
    todaysSales: 12450,
    pendingOrders: 23
  };

  constructor(private router: Router) {}

  navigateToFeature(route: string) {
    this.router.navigate([route]);
  }

  toggleNotifications() {
    this.showNotifications = !this.showNotifications;
    alert('Notifications: 3 new items');
  }

  refreshData() {
    this.stats.todaysSales += Math.floor(Math.random() * 1000);
    alert('Data refreshed successfully!');
  }

  logout() {
    this.router.navigate(['/login']);
  }
}