export interface Drug {
  drugId: number;
  name: string;
  manufacturer: string;
  price: number;
  stock: number;
  storageInstructions?: string;
  isPrescriptionRequired: boolean;
}

export interface CreateDrug {
  name: string;
  manufacturer: string;
  price: number;
  storageInstructions?: string;
  isPrescriptionRequired: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  name: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  status: string;
}