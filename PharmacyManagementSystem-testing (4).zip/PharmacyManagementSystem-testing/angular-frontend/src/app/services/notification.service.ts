import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  time: string;
  read: boolean;
  autoClose?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private notificationsSubject = new BehaviorSubject<Notification[]>([]);
  public notifications$ = this.notificationsSubject.asObservable();

  constructor() {
    // Initialize with some sample notifications
    this.addNotification('warning', '5 items are running low on stock', false);
    this.addNotification('success', 'New order #1234 received', false);
    this.addNotification('info', 'Weekly report is ready', true);
  }

  addNotification(type: Notification['type'], message: string, read: boolean = false, autoClose: boolean = false): void {
    const notification: Notification = {
      id: Date.now() + Math.random(),
      type,
      message,
      time: this.getTimeAgo(new Date()),
      read,
      autoClose
    };

    const currentNotifications = this.notificationsSubject.value;
    this.notificationsSubject.next([notification, ...currentNotifications]);

    // Auto-close notification after 5 seconds if specified
    if (autoClose) {
      setTimeout(() => {
        this.removeNotification(notification.id);
      }, 5000);
    }
  }

  markAsRead(id: number): void {
    const notifications = this.notificationsSubject.value.map(notification =>
      notification.id === id ? { ...notification, read: true } : notification
    );
    this.notificationsSubject.next(notifications);
  }

  removeNotification(id: number): void {
    const notifications = this.notificationsSubject.value.filter(
      notification => notification.id !== id
    );
    this.notificationsSubject.next(notifications);
  }

  markAllAsRead(): void {
    const notifications = this.notificationsSubject.value.map(notification => ({
      ...notification,
      read: true
    }));
    this.notificationsSubject.next(notifications);
  }

  getUnreadCount(): number {
    return this.notificationsSubject.value.filter(n => !n.read).length;
  }

  private getTimeAgo(date: Date): string {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return 'Just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} min ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  }

  // Predefined notification methods for common actions
  showSuccess(message: string, autoClose: boolean = true): void {
    this.addNotification('success', message, false, autoClose);
  }

  showError(message: string, autoClose: boolean = false): void {
    this.addNotification('error', message, false, autoClose);
  }

  showWarning(message: string, autoClose: boolean = false): void {
    this.addNotification('warning', message, false, autoClose);
  }

  showInfo(message: string, autoClose: boolean = true): void {
    this.addNotification('info', message, false, autoClose);
  }
}