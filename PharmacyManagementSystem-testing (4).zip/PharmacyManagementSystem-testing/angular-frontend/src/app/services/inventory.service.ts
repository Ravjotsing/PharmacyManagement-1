import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export interface InventoryItem {
  drugId: number;
  drugName: string;
  quantity: number;
  reorderLevel: number;
}

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private apiUrl = 'https://localhost:5139/api/inventory';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  getAllInventory(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.apiUrl}/view`, { headers: this.getHeaders() });
  }

  getInventoryById(drugId: number): Observable<InventoryItem> {
    return this.http.get<InventoryItem>(`${this.apiUrl}/byId/${drugId}`, { headers: this.getHeaders() });
  }

  getInventoryByName(drugName: string): Observable<InventoryItem> {
    return this.http.get<InventoryItem>(`${this.apiUrl}/byName/${drugName}`, { headers: this.getHeaders() });
  }

  addInventory(inventoryData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add`, inventoryData, { headers: this.getHeaders() });
  }

  updateQuantity(drugName: string, quantityData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update/${drugName}`, quantityData, { headers: this.getHeaders() });
  }
}