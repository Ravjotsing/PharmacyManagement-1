import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface SalesReportRequest {
  startDate?: string;
  endDate?: string;
  drugId?: number;
  paymentMethod?: string;
  format: ReportFormat;
}

export enum ReportFormat {
  CSV = 1,
  Excel = 2,
  PDF = 3
}

export interface Sale {
  salesId: number;
  date: string;
  totalSales: number;
  drugId: number;
  paymentMethod: string;
}

export interface CreateSale {
  date: string;
  totalSales: number;
  drugId: number;
  paymentMethod: string;
}

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  private apiUrl = 'http://localhost:5000/api/sales';

  constructor(private http: HttpClient) {}

  getAllSales(): Observable<Sale[]> {
    return this.http.get<Sale[]>(this.apiUrl);
  }

  getSaleById(id: number): Observable<Sale> {
    return this.http.get<Sale>(`${this.apiUrl}/${id}`);
  }

  createSale(sale: CreateSale): Observable<Sale> {
    return this.http.post<Sale>(this.apiUrl, sale);
  }

  updateSale(id: number, sale: CreateSale): Observable<Sale> {
    return this.http.put<Sale>(`${this.apiUrl}/${id}`, sale);
  }

  deleteSale(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  downloadSalesReport(request: SalesReportRequest): Observable<Blob> {
    const params = new HttpParams()
      .set('startDate', request.startDate || '')
      .set('endDate', request.endDate || '')
      .set('drugId', request.drugId?.toString() || '')
      .set('paymentMethod', request.paymentMethod || '')
      .set('format', request.format.toString());

    return this.http.get(`${this.apiUrl}/report/download`, {
      params: params,
      responseType: 'blob'
    });
  }

  downloadSalesReportPost(request: SalesReportRequest): Observable<Blob> {
    return this.http.post(`${this.apiUrl}/report/download`, request, {
      responseType: 'blob'
    });
  }
}