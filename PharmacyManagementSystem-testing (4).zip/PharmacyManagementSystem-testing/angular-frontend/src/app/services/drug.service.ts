import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Drug, CreateDrug } from '../models/drug.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class DrugService {
  private apiUrl = 'https://localhost:5139/api/Drugs';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  getAllDrugs(): Observable<Drug[]> {
    return this.http.get<Drug[]>(this.apiUrl);
  }

  getDrugById(id: number): Observable<Drug> {
    return this.http.get<Drug>(`${this.apiUrl}/${id}`);
  }

  addDrug(drug: CreateDrug): Observable<Drug> {
    return this.http.post<Drug>(this.apiUrl, drug, { headers: this.getHeaders() });
  }

  updateDrug(id: number, drug: any): Observable<Drug> {
    return this.http.put<Drug>(`${this.apiUrl}/${id}`, drug, { headers: this.getHeaders() });
  }

  deleteDrug(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }
}