import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

export interface DashboardStats {
  totalDrugs: number;
  inventoryItems: number;
  todaysSales: number;
  pendingOrders: number;
  lowStockItems: number;
  totalRevenue: number;
  activeUsers: number;
}

export interface RecentActivity {
  id: number;
  action: string;
  item: string;
  user: string;
  time: string;
  icon: string;
  type: 'success' | 'warning' | 'info' | 'error';
}

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private apiUrl = 'https://localhost:5139/api';
  private statsSubject = new BehaviorSubject<DashboardStats>({
    totalDrugs: 0,
    inventoryItems: 0,
    todaysSales: 0,
    pendingOrders: 0,
    lowStockItems: 0,
    totalRevenue: 0,
    activeUsers: 0
  });

  public stats$ = this.statsSubject.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  getDashboardStats(): Observable<DashboardStats> {
    return this.http.get<DashboardStats>(`${this.apiUrl}/dashboard/stats`, { 
      headers: this.getHeaders() 
    });
  }

  getRecentActivity(): Observable<RecentActivity[]> {
    return this.http.get<RecentActivity[]>(`${this.apiUrl}/dashboard/activity`, { 
      headers: this.getHeaders() 
    });
  }

  updateStats(stats: DashboardStats): void {
    this.statsSubject.next(stats);
  }

  // Simulate real-time data updates
  simulateRealTimeUpdates(): void {
    setInterval(() => {
      const currentStats = this.statsSubject.value;
      const updatedStats: DashboardStats = {
        ...currentStats,
        todaysSales: currentStats.todaysSales + Math.floor(Math.random() * 1000),
        pendingOrders: Math.max(0, currentStats.pendingOrders + Math.floor(Math.random() * 3) - 1),
        activeUsers: Math.floor(Math.random() * 50) + 10
      };
      this.updateStats(updatedStats);
    }, 10000); // Update every 10 seconds
  }

  // Get low stock alerts
  getLowStockAlerts(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/inventory/low-stock`, { 
      headers: this.getHeaders() 
    });
  }

  // Get sales trend data for charts
  getSalesTrend(period: string = '7d'): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/sales/trend?period=${period}`, { 
      headers: this.getHeaders() 
    });
  }
}