import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login.component';
import { LandingComponent } from './components/landing.component';
import { RegisterComponent } from './components/register.component';
import { DrugListComponent } from './components/drug-list.component';
import { SalesReportComponent } from './components/sales-report.component';
import { AdminDashboardComponent } from './components/admin-dashboard.component';
import { AdminDashboardSimpleComponent } from './components/admin-dashboard-simple.component';
import { DrugManagementComponent } from './components/drug-management.component';
import { InventoryManagementComponent } from './components/inventory-management.component';
import { OrdersManagementComponent } from './components/orders-management.component';
import { ToastNotificationComponent } from './components/toast-notification.component';
import { routes } from './app.routes';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LandingComponent,
    RegisterComponent,
    DrugListComponent,
    SalesReportComponent,
    AdminDashboardComponent,
    AdminDashboardSimpleComponent,
    DrugManagementComponent,
    InventoryManagementComponent,
    OrdersManagementComponent,
    ToastNotificationComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }