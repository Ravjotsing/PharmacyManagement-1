# Sales Report Download Feature

## Overview
The Pharmacy Management System now includes a comprehensive sales report download feature that allows users to generate and download sales reports in multiple formats (CSV, Excel, PDF) with various filtering options.

## Features

### 📊 Report Formats
- **CSV**: Comma-separated values for data analysis
- **Excel**: Formatted spreadsheet with calculations and styling
- **PDF**: Professional document for printing and sharing

### 🔍 Filtering Options
- **Date Range**: Filter sales by start and end dates
- **Drug ID**: Filter by specific drug/medication
- **Payment Method**: Filter by payment type (Cash, Credit Card, etc.)

### 🚀 API Endpoints

#### GET /api/sales/report/download
Download report using query parameters:
```
GET /api/sales/report/download?startDate=2024-01-01&endDate=2024-12-31&format=1
```

**Query Parameters:**
- `startDate` (optional): Start date in YYYY-MM-DD format
- `endDate` (optional): End date in YYYY-MM-DD format
- `drugId` (optional): Specific drug ID to filter
- `paymentMethod` (optional): Payment method to filter
- `format` (required): Report format (1=CSV, 2=Excel, 3=PDF)

#### POST /api/sales/report/download
Download report using request body:
```json
{
  "startDate": "2024-01-01",
  "endDate": "2024-12-31",
  "drugId": 1,
  "paymentMethod": "Cash",
  "format": 2
}
```

## Implementation Details

### Backend Components

#### 1. DTOs (Data Transfer Objects)
- `SalesReportRequestDto`: Request parameters for report generation
- `SalesReportDto`: Sales data structure for reports
- `ReportFormat`: Enum for different export formats

#### 2. Services
- `IReportService`: Interface for report generation
- `ReportService`: Implementation with CSV, Excel, and PDF generation

#### 3. Controller Updates
- Added report endpoints to `SalesController`
- Support for both GET and POST methods

### Frontend Components

#### 1. Angular Component
- `SalesReportComponent`: Main component for report interface
- Form with filters and format selection
- Download functionality with progress indication

#### 2. Angular Service
- `SalesService`: HTTP service for API communication
- Methods for both GET and POST report downloads

#### 3. Demo Page
- `sales-report-demo.html`: Standalone demo page
- Preview functionality to see data before download
- Bootstrap styling for professional appearance

## Required NuGet Packages

Add these packages to your .NET project:

```xml
<PackageReference Include="EPPlus" Version="7.0.0" />
<PackageReference Include="iTextSharp" Version="5.5.13.3" />
<PackageReference Include="CsvHelper" Version="30.0.1" />
```

## Setup Instructions

### 1. Backend Setup
1. Install the required NuGet packages
2. Add the `ReportService` to dependency injection in `Program.cs`
3. Ensure the `SalesController` is updated with report endpoints

### 2. Frontend Setup
1. Add the `SalesReportComponent` to your Angular module
2. Include the component in your routing configuration
3. Add Bootstrap CSS for styling (optional but recommended)

### 3. Testing
1. Use the demo page (`sales-report-demo.html`) to test functionality
2. Ensure your backend is running on the correct port
3. Test all three export formats with different filter combinations

## Usage Examples

### Basic CSV Download
```javascript
// GET request
const response = await fetch('/api/sales/report/download?format=1');
const blob = await response.blob();
// Handle file download
```

### Filtered Excel Report
```javascript
// POST request
const response = await fetch('/api/sales/report/download', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    startDate: '2024-01-01',
    endDate: '2024-12-31',
    paymentMethod: 'Credit Card',
    format: 2
  })
});
```

### PDF Report with Drug Filter
```javascript
const response = await fetch('/api/sales/report/download', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    drugId: 5,
    format: 3
  })
});
```

## File Structure

```
PharmacyManagement/
├── Controllers/
│   └── SalesController.cs (updated)
├── DTO/
│   └── SalesReportDto.cs (new)
├── Interface/
│   └── IReportService.cs (new)
├── Services/
│   └── ReportService.cs (new)
└── Program.cs (updated)

angular-frontend/
├── src/app/
│   ├── components/
│   │   └── sales-report.component.ts (new)
│   │   └── sales-report.component.html (new)
│   ├── services/
│   │   └── sales.service.ts (new)
│   └── app.module.ts (updated)
└── sales-report-demo.html (demo page)
```

## Security Considerations

- Ensure proper authentication for report endpoints
- Validate all input parameters to prevent injection attacks
- Consider rate limiting for report generation
- Implement proper error handling and logging

## Performance Notes

- Large datasets may take time to generate, especially PDF reports
- Consider implementing pagination for very large reports
- Add caching for frequently requested reports
- Monitor memory usage during Excel and PDF generation

## Troubleshooting

### Common Issues

1. **"Cannot connect to backend"**
   - Ensure backend is running on correct port
   - Check CORS configuration

2. **"Report generation failed"**
   - Verify database connection
   - Check that sales data exists
   - Ensure all required packages are installed

3. **"File download not working"**
   - Check browser download settings
   - Verify content-type headers
   - Ensure proper blob handling in frontend

### Debug Tips

- Check browser network tab for API responses
- Review backend logs for detailed error messages
- Test with minimal data first
- Verify all dependencies are properly installed

## Future Enhancements

- Add more chart types and visualizations
- Implement scheduled report generation
- Add email delivery of reports
- Include more advanced filtering options
- Add report templates and customization
- Implement report caching and optimization