@echo off
echo Starting Pharmacy Management System...
echo.

echo Starting Backend (.NET API)...
start "Backend" cmd /k "cd PharmacyManagement && dotnet run"

echo Waiting for backend to start...
timeout /t 10 /nobreak > nul

echo Starting Frontend (Angular)...
start "Frontend" cmd /k "cd angular-frontend && npm start"

echo.
echo Both applications are starting...
echo Backend will be available at: https://localhost:5139
echo Frontend will be available at: http://localhost:4200
echo.
pause